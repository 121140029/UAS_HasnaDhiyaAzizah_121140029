<?php
require_once('middleware/auth.php');

header('Location: views/home.php');
exit;